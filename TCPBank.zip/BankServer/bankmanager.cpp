#include "bankmanager.h"

BankManager::BankManager(QObject *parent)
    : QObject{parent}
{

}

void Boo()
{
   MainWindow a;
   a.readSocket();

}
