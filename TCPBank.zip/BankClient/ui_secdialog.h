/********************************************************************************
** Form generated from reading UI file 'secdialog.ui'
**
** Created by: Qt User Interface Compiler version 5.15.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SECDIALOG_H
#define UI_SECDIALOG_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPlainTextEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_SecDialog
{
public:
    QWidget *layoutWidget;
    QHBoxLayout *horizontalLayout_3;
    QVBoxLayout *verticalLayout_3;
    QLabel *label_yourDeposit;
    QLabel *label_realDeposit;
    QVBoxLayout *verticalLayout_2;
    QHBoxLayout *horizontalLayout;
    QLabel *label;
    QLineEdit *lineEdit_amountOfMoney;
    QLabel *label_2;
    QHBoxLayout *horizontalLayout_2;
    QLabel *label_3;
    QLineEdit *lineEdit_accountNumber;
    QLabel *label_4;
    QVBoxLayout *verticalLayout;
    QLabel *label_5;
    QLineEdit *lineEdit_recieverName;
    QPushButton *pushButton_Send;
    QWidget *layoutWidget1;
    QVBoxLayout *verticalLayout_4;
    QLineEdit *lineEdit_amountOfMoney_2;
    QHBoxLayout *horizontalLayout_4;
    QPushButton *pushButton_Deposit;
    QPushButton *pushButton_Withdraw;
    QLabel *label_serverStatus;
    QPlainTextEdit *plainTextEdit_show;
    QLineEdit *lineEdit_last;

    void setupUi(QDialog *SecDialog)
    {
        if (SecDialog->objectName().isEmpty())
            SecDialog->setObjectName(QString::fromUtf8("SecDialog"));
        SecDialog->resize(810, 552);
        layoutWidget = new QWidget(SecDialog);
        layoutWidget->setObjectName(QString::fromUtf8("layoutWidget"));
        layoutWidget->setGeometry(QRect(42, 61, 731, 211));
        horizontalLayout_3 = new QHBoxLayout(layoutWidget);
        horizontalLayout_3->setObjectName(QString::fromUtf8("horizontalLayout_3"));
        horizontalLayout_3->setContentsMargins(0, 0, 0, 0);
        verticalLayout_3 = new QVBoxLayout();
        verticalLayout_3->setObjectName(QString::fromUtf8("verticalLayout_3"));
        label_yourDeposit = new QLabel(layoutWidget);
        label_yourDeposit->setObjectName(QString::fromUtf8("label_yourDeposit"));
        label_yourDeposit->setStyleSheet(QString::fromUtf8("font: 700 12pt \"Segoe UI\";\n"
"color: rgb(0, 0, 0);"));

        verticalLayout_3->addWidget(label_yourDeposit);

        label_realDeposit = new QLabel(layoutWidget);
        label_realDeposit->setObjectName(QString::fromUtf8("label_realDeposit"));

        verticalLayout_3->addWidget(label_realDeposit);


        horizontalLayout_3->addLayout(verticalLayout_3);

        verticalLayout_2 = new QVBoxLayout();
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        label = new QLabel(layoutWidget);
        label->setObjectName(QString::fromUtf8("label"));

        horizontalLayout->addWidget(label);

        lineEdit_amountOfMoney = new QLineEdit(layoutWidget);
        lineEdit_amountOfMoney->setObjectName(QString::fromUtf8("lineEdit_amountOfMoney"));

        horizontalLayout->addWidget(lineEdit_amountOfMoney);

        label_2 = new QLabel(layoutWidget);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        horizontalLayout->addWidget(label_2);


        verticalLayout_2->addLayout(horizontalLayout);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        label_3 = new QLabel(layoutWidget);
        label_3->setObjectName(QString::fromUtf8("label_3"));

        horizontalLayout_2->addWidget(label_3);

        lineEdit_accountNumber = new QLineEdit(layoutWidget);
        lineEdit_accountNumber->setObjectName(QString::fromUtf8("lineEdit_accountNumber"));

        horizontalLayout_2->addWidget(lineEdit_accountNumber);

        label_4 = new QLabel(layoutWidget);
        label_4->setObjectName(QString::fromUtf8("label_4"));

        horizontalLayout_2->addWidget(label_4);


        verticalLayout_2->addLayout(horizontalLayout_2);

        verticalLayout = new QVBoxLayout();
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        label_5 = new QLabel(layoutWidget);
        label_5->setObjectName(QString::fromUtf8("label_5"));

        verticalLayout->addWidget(label_5);

        lineEdit_recieverName = new QLineEdit(layoutWidget);
        lineEdit_recieverName->setObjectName(QString::fromUtf8("lineEdit_recieverName"));

        verticalLayout->addWidget(lineEdit_recieverName);

        pushButton_Send = new QPushButton(layoutWidget);
        pushButton_Send->setObjectName(QString::fromUtf8("pushButton_Send"));
        pushButton_Send->setStyleSheet(QString::fromUtf8("font: 700 12pt \"Segoe UI\";\n"
"color: rgb(255, 255, 255);"));

        verticalLayout->addWidget(pushButton_Send);


        verticalLayout_2->addLayout(verticalLayout);


        horizontalLayout_3->addLayout(verticalLayout_2);

        layoutWidget1 = new QWidget(SecDialog);
        layoutWidget1->setObjectName(QString::fromUtf8("layoutWidget1"));
        layoutWidget1->setGeometry(QRect(40, 311, 271, 111));
        verticalLayout_4 = new QVBoxLayout(layoutWidget1);
        verticalLayout_4->setObjectName(QString::fromUtf8("verticalLayout_4"));
        verticalLayout_4->setContentsMargins(10, 12, 10, 20);
        lineEdit_amountOfMoney_2 = new QLineEdit(layoutWidget1);
        lineEdit_amountOfMoney_2->setObjectName(QString::fromUtf8("lineEdit_amountOfMoney_2"));

        verticalLayout_4->addWidget(lineEdit_amountOfMoney_2);

        horizontalLayout_4 = new QHBoxLayout();
        horizontalLayout_4->setObjectName(QString::fromUtf8("horizontalLayout_4"));
        pushButton_Deposit = new QPushButton(layoutWidget1);
        pushButton_Deposit->setObjectName(QString::fromUtf8("pushButton_Deposit"));
        pushButton_Deposit->setStyleSheet(QString::fromUtf8("font: 700 12pt \"Segoe UI\";\n"
"color: rgb(255, 255, 255);"));

        horizontalLayout_4->addWidget(pushButton_Deposit);

        pushButton_Withdraw = new QPushButton(layoutWidget1);
        pushButton_Withdraw->setObjectName(QString::fromUtf8("pushButton_Withdraw"));
        pushButton_Withdraw->setStyleSheet(QString::fromUtf8("font: 700 12pt \"Segoe UI\";\n"
"color: rgb(255, 255, 255);"));

        horizontalLayout_4->addWidget(pushButton_Withdraw);


        verticalLayout_4->addLayout(horizontalLayout_4);

        label_serverStatus = new QLabel(SecDialog);
        label_serverStatus->setObjectName(QString::fromUtf8("label_serverStatus"));
        label_serverStatus->setGeometry(QRect(20, 500, 111, 31));
        plainTextEdit_show = new QPlainTextEdit(SecDialog);
        plainTextEdit_show->setObjectName(QString::fromUtf8("plainTextEdit_show"));
        plainTextEdit_show->setGeometry(QRect(340, 310, 421, 111));
        lineEdit_last = new QLineEdit(SecDialog);
        lineEdit_last->setObjectName(QString::fromUtf8("lineEdit_last"));
        lineEdit_last->setGeometry(QRect(340, 430, 421, 24));

        retranslateUi(SecDialog);
        QObject::connect(pushButton_Send, SIGNAL(clicked()), lineEdit_amountOfMoney, SLOT(copy()));
        QObject::connect(pushButton_Send, SIGNAL(clicked()), lineEdit_accountNumber, SLOT(copy()));
        QObject::connect(pushButton_Send, SIGNAL(clicked()), lineEdit_recieverName, SLOT(copy()));

        QMetaObject::connectSlotsByName(SecDialog);
    } // setupUi

    void retranslateUi(QDialog *SecDialog)
    {
        SecDialog->setWindowTitle(QCoreApplication::translate("SecDialog", "Dialog", nullptr));
        label_yourDeposit->setText(QCoreApplication::translate("SecDialog", "Your deposit =", nullptr));
        label_realDeposit->setText(QCoreApplication::translate("SecDialog", "<html><head/><body><p><span style=\" font-size:12pt; font-weight:700;\">TextLabel</span></p></body></html>", nullptr));
        label->setText(QCoreApplication::translate("SecDialog", "<html><head/><body><p><span style=\" font-size:12pt; font-weight:700;\">Transfer</span></p></body></html>", nullptr));
        label_2->setText(QCoreApplication::translate("SecDialog", "<html><head/><body><p><span style=\" font-size:12pt; font-weight:700;\">Lira</span></p></body></html>", nullptr));
        label_3->setText(QCoreApplication::translate("SecDialog", "<html><head/><body><p><span style=\" font-size:12pt; font-weight:700;\">to</span></p></body></html>", nullptr));
        label_4->setText(QCoreApplication::translate("SecDialog", "<html><head/><body><p><span style=\" font-size:12pt; font-weight:700;\">account number</span></p></body></html>", nullptr));
        label_5->setText(QCoreApplication::translate("SecDialog", "<html><head/><body><p><span style=\" font-size:12pt; font-weight:700;\">Name of the reciever is:</span></p></body></html>", nullptr));
        pushButton_Send->setText(QCoreApplication::translate("SecDialog", "Send", nullptr));
        pushButton_Deposit->setText(QCoreApplication::translate("SecDialog", "Deposit", nullptr));
        pushButton_Withdraw->setText(QCoreApplication::translate("SecDialog", "Withdraw", nullptr));
        label_serverStatus->setText(QCoreApplication::translate("SecDialog", "<html><head/><body><p><span style=\" font-size:12pt; font-weight:700;\">TextLabel</span></p></body></html>", nullptr));
    } // retranslateUi

};

namespace Ui {
    class SecDialog: public Ui_SecDialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SECDIALOG_H
